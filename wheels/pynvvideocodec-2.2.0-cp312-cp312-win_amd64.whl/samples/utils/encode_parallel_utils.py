# This copyright notice applies to this file only
#
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: MIT
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

"""
Helper module for parallel processing in video encoding.
"""

import os
import threading
import multiprocessing
from typing import Callable, Any, Dict, Union
import pycuda.driver as cuda
import PyNvVideoCodec as nvc
from .Utils import AppFramePerf
from .frame_utils import get_frame_size
from .encode_parser import PERF_MAX_FRAMES

def print_performance_summary(mode: str, num_workers: int, total_frames: int, duration: float) -> None:
    """Print performance statistics for parallel encoding/decoding."""
    print(f"\n--- {mode.capitalize()} Performance Summary ---")
    print(f"Number of {mode}: {num_workers}")
    print(f"Total frames processed: {total_frames}")
    if duration > 0:
        fps = total_frames / duration
        print(f"Duration: {duration:.2f} seconds")
        print(f"Total FPS: {fps:.2f}")
        print(f"Average FPS per {mode[:-1]}: {fps / num_workers:.2f}")

def encode_thread_worker(
    thread_id: int,
    input_file: str,
    encoder: nvc.PyNvEncoder,
    device_data: cuda.DeviceAllocation,
    frame_size: int,
    width: int,
    height: int,
    fmt: str,
    frame_count: int,
    result_queue: Union[multiprocessing.Queue, 'queue.Queue']
) -> None:
    """Worker function for threaded encoding."""
    try:
        worker_name = f"Thread-{thread_id + 1}"  # 1-based indexing
        print(f"Starting encode worker {worker_name}")
        
        # Calculate frames to process
        file_size = os.path.getsize(input_file)
        available_frames = file_size // frame_size
        
        # Determine how many frames to encode
        frames_to_process = min(frame_count or available_frames, available_frames, PERF_MAX_FRAMES)
        
        # Encode frames
        frames_encoded = 0
        for i in range(frames_to_process):
            input_gpu_frame = AppFramePerf(width, height, fmt, device_data, i)
            pic_params = nvc.NV_ENC_PIC_PARAMS()
            pic_params.inputTimeStamp = i
            encoder.Encode(input_gpu_frame, pic_params)
            frames_encoded += 1
        
        # Flush encoder
        encoder.EndEncode()
        print(f"Worker {worker_name} completed encoding {frames_encoded} frames")
        result_queue.put(frames_encoded)
        
    except Exception as e:
        print(f"Worker {worker_name}: An unexpected error occurred: {e}")
        result_queue.put(0)

def encode_process_worker(
    process_id: int,
    input_file: str,
    width: int,
    height: int,
    fmt: str,
    ipc_handle: Any,
    frame_size: int,
    config: Dict[str, Any],
    frame_count: int,
    result_queue: multiprocessing.Queue,
    ready_queue: multiprocessing.Queue,
    go_event: Any,
) -> None:
    """Worker function for multiprocess encoding.

    Signals readiness on ``ready_queue`` after encoder and IPC memory are set up,
    then blocks on ``go_event`` so the parent can measure encode-only duration.
    """
    worker_name = f"Process-{process_id + 1}"  # 1-based indexing
    print(f"Starting encode worker {worker_name}")

    worker_context = None
    encoder = None
    try:
        # Match thread mode: explicit context + stream (avoids primary-context + extra stream path).
        # Open IPC memory in this context before CreateEncoder so NVENC sees a consistent CUcontext.
        cuda.init()
        gpu_id = int(config.get("gpu_id", 0))
        worker_context = cuda.Device(gpu_id).make_context()
        worker_stream = cuda.Stream()
        device_data = cuda.IPCMemoryHandle(ipc_handle)
        encoder = nvc.CreateEncoder(
            width,
            height,
            fmt,
            False,
            cudacontext=worker_context.handle,
            cudastream=worker_stream.handle,
            **config,
        )
    except Exception as e:
        print(f"Worker {worker_name}: setup failed: {e}")
        ready_queue.put((process_id, False))
        result_queue.put(0)
        if worker_context is not None:
            try:
                worker_context.pop()
                worker_context.detach()
            except Exception:
                pass
        return

    file_size = os.path.getsize(input_file)
    available_frames = file_size // frame_size
    frames_to_process = min(frame_count or available_frames, available_frames, PERF_MAX_FRAMES)

    ready_queue.put((process_id, True))
    go_event.wait()

    try:
        frames_encoded = 0
        for i in range(frames_to_process):
            input_gpu_frame = AppFramePerf(width, height, fmt, device_data, i)
            pic_params = nvc.NV_ENC_PIC_PARAMS()
            pic_params.inputTimeStamp = i
            encoder.Encode(input_gpu_frame, pic_params)
            frames_encoded += 1

        encoder.EndEncode()
        print(f"Worker {worker_name} completed encoding {frames_encoded} frames")
        result_queue.put(frames_encoded)

    except Exception as e:
        print(f"Worker {worker_name}: An unexpected error occurred: {e}")
        result_queue.put(0)
    finally:
        encoder = None
        if worker_context is not None:
            try:
                worker_context.pop()
                worker_context.detach()
            except Exception:
                pass
