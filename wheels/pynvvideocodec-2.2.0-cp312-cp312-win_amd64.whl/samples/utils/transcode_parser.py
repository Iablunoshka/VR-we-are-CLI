# This copyright notice applies to this file only
#
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: MIT
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

"""
Argument parsing utilities for transcoding applications.

Two parser families live here, one per transcode sample:

    add_transcode_args / parse_transcode_args
        Segment-transcode CLI used by samples/basic/create_video_segments.py.
        Exposes -i, -s (segments file), -c (config file), -o (output
        template), -g.  Do not change without auditing that sample.

    add_advanced_transcode_args / load_advanced_transcode_config /
    parse_advanced_transcode_args
        Full-pipeline transcode CLI used by samples/advanced/transcode.py.
        Exposes -i, -o, -c (codec), -g, -fps, -json, --dump, --bframes.
        load_advanced_transcode_config(args) returns a dict of encoder
        kwargs ready to splat into nvc.CreateEncoder().
"""

import argparse
import json
import os
from pathlib import Path
from os.path import join, dirname, abspath

def add_transcode_args(parser):
    """Add transcoding-specific arguments to an argument parser.

    Args:
        parser (argparse.ArgumentParser): The parser to add arguments to

    Returns:
        None
    """
    parser.add_argument("-i", "--input_file_path", required=True, type=str,
                       help="Path to input video file")
    
    parser.add_argument("-s", "--segments_file_path", type=str,
                       default=join(dirname(dirname(__file__)),"basic", "segments.txt"),
                       help="Path to segments file (format: 'start_time end_time' per line)")
    
    parser.add_argument("-c", "--config_file_path", type=str,
                       default=join(dirname(dirname(__file__)),"basic", "transcode_config.json"),
                       help="Path to transcoder config JSON file")
    
    parser.add_argument("-o", "--output_template", type=str,
                       default="{input_file_name}_segment",
                       help="Output filename template")
    
    parser.add_argument("-g", "--gpu_id", type=int, default=0,
                       help="GPU ID to use (default: 0)")

def parse_transcode_args(description):
    """Parse command line arguments for transcoding applications.

    Args:
        description (str): Description of the application

    Returns:
        argparse.Namespace: Parsed arguments
    """
    parser = argparse.ArgumentParser(description=description)
    add_transcode_args(parser)
    return parser.parse_args()


def add_advanced_transcode_args(parser):
    """Add CLI arguments for the full-pipeline transcoder.

    Mirrors the historical CLI of samples/advanced/transcode.py exactly,
    so existing user invocations keep working.  Distinct from
    add_transcode_args() above, which targets the segment-transcode
    sample (samples/basic/create_video_segments.py) and exposes a
    different set of flags.

    Args:
        parser (argparse.ArgumentParser): The parser to add arguments to.
    """
    parser.add_argument(
        "-i", "--input",
        type=Path,
        required=True,
        help="Input video file (container or elementary bitstream).",
    )
    parser.add_argument(
        "-o", "--output",
        type=Path,
        required=True,
        help="Output video file. A container extension (.mp4, .mov, .mkv, "
             ".webm, .avi) triggers muxing of both video and audio.",
    )
    parser.add_argument(
        "-c", "--codec",
        type=str,
        default=None,
        choices=["H264", "HEVC", "AV1"],
        help="Output codec; if not specified, uses the input codec.",
    )
    parser.add_argument(
        "-g", "--gpu_id",
        type=int,
        default=0,
        help="GPU ID to use. Default: 0.",
    )
    parser.add_argument(
        "-fps", "--fps",
        type=int,
        default=0,
        help="Output FPS override; only honoured for elementary-bitstream "
             "input (containers carry their own FPS in metadata, which "
             "always wins). Default: 0 (auto from input).",
    )
    parser.add_argument(
        "-json", "--config",
        type=Path,
        default=None,
        help="Encoder configuration JSON file. Default: encode_config.json "
             "next to the transcode sample.",
    )
    parser.add_argument(
        "--dump",
        action="store_true",
        help="Dump decoded YUV frames + encoded bitstream to "
             "<output_stem>_decoded.yuv / <output_stem>_encoded.<ext>.",
    )
    parser.add_argument(
        "--bframes",
        type=int,
        default=None,
        metavar="N",
        help="Override encoder B-frame count (encoder key 'bf'). If "
             "omitted, the JSON config / encoder default applies.",
    )


def load_advanced_transcode_config(args):
    """Build the encoder config dict for the full-pipeline transcoder.

    Loads the JSON config file (default: samples/advanced/encode_config.json),
    upper-cases the preset, and applies the CLI overrides:

      * --codec      -> config["codec"] (lower-case)
      * --bframes N  -> config["bf"]    (string, clamped >= 0)
      * --fps N      -> config["fps"]   (string, only when N > 0;
                                         ignored by the encoder when a
                                         source AVFormatContext is also
                                         provided -- ExtractSourceFrameRate
                                         in NvEncoderClInterface always
                                         wins for container inputs).

    Args:
        args (argparse.Namespace): Output of parse_advanced_transcode_args.

    Returns:
        dict: kwargs ready to splat into nvc.CreateEncoder().
    """
    config = {}
    config_path = args.config or Path(
        join(dirname(dirname(abspath(__file__))), "advanced", "encode_config.json")
    )
    if config_path.exists():
        with open(config_path) as f:
            config = json.load(f)
        if "preset" in config:
            config["preset"] = config["preset"].upper()
    if args.codec is not None:
        config["codec"] = args.codec.lower()
    if args.bframes is not None:
        config["bf"] = str(max(0, int(args.bframes)))
    if args.fps and args.fps > 0:
        config["fps"] = str(int(args.fps))
    return config


def parse_advanced_transcode_args(description=None):
    """Parse + load config for the full-pipeline transcoder.

    Returns the argparse.Namespace with one extra attribute:

      * args.config -- dict of encoder kwargs (JSON + CLI overrides),
                       ready to splat into nvc.CreateEncoder().

    Distinct from parse_transcode_args() above, which targets the
    segment-transcode sample (samples/basic/create_video_segments.py).

    Args:
        description (str | None): argparse description string.

    Returns:
        argparse.Namespace
    """
    parser = argparse.ArgumentParser(description=description)
    add_advanced_transcode_args(parser)
    args = parser.parse_args()
    args.config = load_advanced_transcode_config(args)
    return args
