# This copyright notice applies to this file only
#
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: MIT
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

"""
Transcode video files using NVIDIA's GPU zero-copy pipeline -- demux ->
NVDEC -> NVENC -> mux, with audio passthrough.

It shows how to:
1. Create a runtime CUDA context and stream and pass them to decoder + encoder
2. Decode an input video file to GPU memory
3. Re-encode the decoded frames in-place (no host round-trip) to a different
   codec / container
4. Demux video + audio in lockstep (DemuxNoSkipAudio) and mux both to the
   output container, preserving the source's A/V interleave + bit-exact PTS

CLI is provided by samples/utils/transcode_parser.py
(parse_advanced_transcode_args).  Run with `--help` for the flag list.

Example:
    # Transcode H264 -> HEVC, mux to MP4 (video + audio in order)
    python transcode.py -i input.mp4 -o output.mp4 -c HEVC

    # Same, with diagnostic YUV + raw bitstream dump
    python transcode.py -i input.mp4 -o output.mp4 -c HEVC --dump

    # Override encoder bitrate / preset / etc. via JSON
    python transcode.py -i input.mp4 -o output.mp4 -c H264 -json my_config.json
"""

import sys
from pathlib import Path
from os.path import dirname, abspath

import pycuda.driver as cuda

# Add the parent directory to Python path so `utils.*` imports resolve
current_dir = dirname(abspath(__file__))
parent_dir = dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

import PyNvVideoCodec as nvc

from utils.Utils import get_frame_data, GetChromaFormat, GetVideoCodec
from utils.transcode_parser import parse_advanced_transcode_args


def transcode(gpu_id, input_path, output_path, encoder_config,
              dump_diagnostics=False):
    """Decode + encode + mux a single video file end-to-end on the GPU.

    Parameters:
        gpu_id (int): GPU ordinal.
        input_path (str): Path to the input video file (any container or
            elementary bitstream FFmpeg can demux).
        output_path (str): Path to the output video file.  A container
            extension (.mp4 / .mov / .mkv / ...) triggers muxing of both
            video and audio.
        encoder_config (dict): Encoder kwargs (codec, preset, bf, fps, ...)
            as produced by load_advanced_transcode_config().  This dict is
            mutated in-place with the GPU/CUDA/source-context handles
            before being splatted into nvc.CreateEncoder.
        dump_diagnostics (bool): If True, dump decoded YUV +
            encoded bitstream to <output_stem>_decoded.yuv /
            <output_stem>_encoded.<ext> for offline inspection.
    """
    print("Using GPU buffer mode for transcoding")

    cuda_ctx = None
    cuda_stream = None
    nv_dmx = None
    nv_dec = None
    nv_enc = None
    muxer = None
    dec_dump_file = None
    enc_dump_file = None

    try:
        # CUDA context + stream shared by decoder and encoder.
        cuda.init()
        cuda_device = cuda.Device(gpu_id)
        cuda_ctx = cuda_device.retain_primary_context()
        cuda_ctx.push()
        cuda_stream = cuda.Stream()
        print(f"Created CUDA context and stream for GPU {gpu_id}")

        # Demuxer + input-stream metadata.
        nv_dmx = nvc.CreateDemuxer(filename=input_path)
        width = nv_dmx.Width()
        height = nv_dmx.Height()
        input_codec = nv_dmx.GetNvCodecId()
        print(f"Input video: {width}x{height} @ {nv_dmx.FrameRate()} FPS "
              f"({nv_dmx.GetContainerName()})")
        print(f"Input codec: {input_codec}")

        # Codec / preset defaults (only used if JSON / CLI didn't set them).
        encoder_config.setdefault("codec", GetVideoCodec(nv_dmx).lower())
        encoder_config.setdefault("preset", "P4")

        output_format = GetChromaFormat(nv_dmx)

        nv_dec = nvc.CreateDecoder(
            gpuid=gpu_id,
            codec=input_codec,
            cudacontext=cuda_ctx.handle,
            cudastream=cuda_stream.handle,
            usedevicememory=1,
        )

        # Hand the source AVFormatContext to the encoder.  This single
        # handle drives three pieces of bit-exactness automatically
        # (see NvEncoderClInterface.cpp):
        #   * ExtractSourceFrameRate   -> NVENC frameRateNum/Den (VFR)
        #   * ExtractSourceColorMeta   -> NVENC SPS VUI color signals
        #   * HasSourceAVFormatContext -> global_header (container-mode)
        # Callers without a source context (encode.py + raw YUV, matrix
        # tests) skip all three paths and keep their existing elementary-
        # stream defaults.
        encoder_config["gpu_id"] = gpu_id
        encoder_config["cudacontext"] = cuda_ctx.handle
        encoder_config["cudastream"] = cuda_stream.handle
        encoder_config["source_av_format_context"] = int(
            nv_dmx.GetAVFormatInputContext()
        )

        nv_enc = nvc.CreateEncoder(
            width, height, output_format, False, **encoder_config,
        )

        print(f"Output codec: {encoder_config['codec']}")
        print(f"Output format: {output_format}")
        print(f"B-frames (encoder): {nv_enc.GetNumBFrames()}")
        print(f"Output timebase: {nv_dmx.GetTimebaseNum()}/"
              f"{nv_dmx.GetTimebaseDen()} (matches input)")

        # Diagnostic dump files (decoded frames, encoded bitstream).
        if dump_diagnostics:
            enc_stem = Path(output_path).stem
            codec_ext = {"h264": "h264", "hevc": "hevc", "av1": "av1"}.get(
                encoder_config["codec"].lower(), "bin")
            dec_dump_path = Path(output_path).parent / f"{enc_stem}_decoded.yuv"
            enc_dump_path = Path(output_path).parent / f"{enc_stem}_encoded.{codec_ext}"
            dec_dump_file = open(dec_dump_path, "wb")
            enc_dump_file = open(enc_dump_path, "wb")
            print(f"Diagnostic dump: decoded -> {dec_dump_path}, "
                  f"encoded -> {enc_dump_path}")

        muxer = nvc.FFmpegMuxer(
            file_path=output_path,
            media_format=nvc.GetMediaFormat(output_path),
            in_format_context=nv_dmx.GetAVFormatInputContext(),
            codec=encoder_config["codec"].lower(),
            width=width,
            height=height,
            extradata=nv_enc.GetSequenceParams(),
        )

        # All A/V interleave bookkeeping, B-frame DTS slack, and VFR PTS
        # correction live inside FFmpegMuxer (see RecordSourceVideoPacket /
        # MuxVideoPacket / MuxPassthroughPacket / Finalize).  This loop is
        # the canonical "decode -> encode -> mux" reference and stays short
        # enough that a user can copy it into their own app.
        input_frame_idx = 0
        while True:
            pkt = nv_dmx.DemuxNoSkipAudio()

            if pkt.is_video or pkt.bsl == 0:
                muxer.RecordSourceVideoPacket(pkt)

                for decoded_frame in nv_dec.Decode(pkt):
                    pic_params = nvc.NV_ENC_PIC_PARAMS()
                    pic_params.inputTimeStamp = input_frame_idx
                    input_frame_idx += 1

                    if dump_diagnostics:
                        frame_data = get_frame_data(decoded_frame, use_device_memory=1)
                        dec_dump_file.write(bytearray(frame_data))

                    for enc_pkt in nv_enc.Encode(decoded_frame, pic_params):
                        if dump_diagnostics:
                            enc_dump_file.write(bytes(enc_pkt['data']))
                        muxer.MuxVideoPacket(
                            bytes(enc_pkt['data']),
                            enc_pkt['picture_type'],
                            enc_pkt['timestamp'],
                        )

                if pkt.bsl == 0:
                    break
            else:
                muxer.MuxPassthroughPacket(pkt)

        for enc_pkt in nv_enc.EndEncode():
            if dump_diagnostics:
                enc_dump_file.write(bytes(enc_pkt['data']))
            muxer.MuxVideoPacket(
                bytes(enc_pkt['data']),
                enc_pkt['picture_type'],
                enc_pkt['timestamp'],
            )

        muxer.Finalize()

        print(f"Output file: {output_path}")

    except nvc.PyNvVCExceptionUnsupported as e:
        print(f"Unsupported operation: {e}")
        raise
    except cuda.Error as e:
        print(f"CUDA error (context/stream): {e}")
        raise
    except Exception as e:
        print(f"Error during transcoding: {e}")
        raise
    finally:
        # Close diagnostic dump files
        if dec_dump_file is not None:
            dec_dump_file.close()
        if enc_dump_file is not None:
            enc_dump_file.close()
        # Cleanup resources in reverse order of creation
        if muxer is not None:
            del muxer
        if nv_enc is not None:
            del nv_enc
        if nv_dec is not None:
            del nv_dec
        if nv_dmx is not None:
            del nv_dmx
        if cuda_stream is not None:
            cuda_stream.synchronize()
            del cuda_stream
        if cuda_ctx is not None:
            cuda_ctx.pop()
            del cuda_ctx


if __name__ == "__main__":
    args = parse_advanced_transcode_args(
        "Transcode video files using GPU zero-copy pipeline -- convert "
        "from one codec/format to another."
    )

    print("=" * 60)
    print("TRANSCODER CONFIGURATION")
    print("=" * 60)
    print(f"Input file:       {args.input}")
    print(f"Output file:      {args.output}")
    print(f"Codec:            {args.codec if args.codec else 'from input'}")
    print(f"GPU ID:           {args.gpu_id}")
    print(f"FPS override:     {args.fps if args.fps else 'auto (from input)'}")
    print(f"Dump diagnostics: {args.dump}")
    print(f"B-frames (CLI):   "
          f"{args.bframes if args.bframes is not None else 'config default'}")
    print("Resolution / format: from input")
    print("=" * 60)

    transcode(
        args.gpu_id,
        args.input.as_posix(),
        args.output.as_posix(),
        args.config,
        dump_diagnostics=args.dump,
    )

    print("=" * 60)
    print("TRANSCODE COMPLETE")
    print("=" * 60)
