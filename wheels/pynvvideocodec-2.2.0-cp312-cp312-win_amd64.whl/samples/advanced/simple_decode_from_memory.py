# This copyright notice applies to this file only
#
# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: MIT
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.


'''
This sample demonstrates that SimpleDecoder can decode directly from in-memory
sources -- no temporary file required. It showcases every supported in-memory
input type in one place:

  1. bytes        -- an immutable in-memory buffer
  2. bytearray    -- a mutable in-memory buffer
  3. memoryview   -- a zero-copy view over a buffer
  4. BinaryIO     -- any seekable file-like object (file handle, io.BytesIO,
                     tarfile member, S3/HTTP range-reader, etc.)

There are two distinct mechanisms under the hood:

  * bytes / bytearray / memoryview ("bytestream"):
      The entire buffer is copied once into native memory, then FFmpeg reads
      from it. Fast per-read (no Python callbacks), uses memory proportional
      to the file size. Best when the whole clip is already in RAM.

  * BinaryIO stream:
      The data stays in the source; FFmpeg pulls only the bytes it needs
      (container headers + the packets for the requested frames) on demand by
      calling the object's read()/seek() methods. No full-file copy. Best for
      large videos or remote/archived sources (tar, S3, HTTP).

All input types are fully SEEKABLE and support the complete SimpleDecoder API:
len(), random access (decoder[i]), slicing, out-of-order batch access
(get_batch_frames_by_index), seek_to_index, and stream metadata.

This is the key difference from decode_from_memory_buffer.py, which uses the
older streaming (non-seekable) callback demuxer and only supports sequential
decode.

Usage: python simple_decode_from_memory.py -i <input_file>
Example: python simple_decode_from_memory.py -i input.mp4

Arguments:
  -i: Input video file (container format such as MP4, MKV, etc.)
  -g: GPU ID to use (default: 0)
'''

import argparse
import io

import PyNvVideoCodec as nvc


def exercise_decoder(decoder, source_label):
    """Run the full seekable SimpleDecoder contract against any in-memory source."""
    total_frames = len(decoder)
    metadata = decoder.get_stream_metadata()

    print(f"  Source type      : {source_label}")
    print(f"  Total frames     : {total_frames}")
    print(f"  Resolution       : {metadata.width}x{metadata.height}")
    print(f"  Codec            : {metadata.codec_name}")
    print(f"  Average FPS      : {metadata.average_fps:.2f}")
    print(f"  Duration         : {metadata.duration:.3f}s")

    # Random access via decoder[i]: fetch the first and last frame from the
    # in-memory source.
    # NOTE: the default output is NATIVE (NV12 for 8-bit 4:2:0). An NV12 frame is
    # returned as a single 2D buffer of shape (height * 3 / 2, width): the luma
    # plane (height x width) stacked on top of the interleaved chroma plane
    # (height/2 x width). So a 1920x1080 picture has buffer shape (1620, 1920) --
    # that is the NV12 layout, not a different resolution. Use
    # output_color_type=nvc.OutputColorType.RGB for a (height, width, 3) image shape.
    for idx in [0, total_frames - 1]:
        frame = decoder[idx]
        print(f"  decoder[{idx:>3}]     : NV12 buffer shape={tuple(frame.shape)} "
              f"(picture {metadata.width}x{metadata.height})")


def main():
    parser = argparse.ArgumentParser(
        description="Demonstrates SimpleDecoder decoding from bytes, bytearray, "
                    "memoryview, and BinaryIO stream inputs."
    )
    parser.add_argument("-i", "--input", required=True, help="Input video file path")
    parser.add_argument("-g", "--gpu_id", type=int, default=0, help="GPU ID (default: 0)")
    args = parser.parse_args()

    # Read the file once; we reuse the raw bytes to build each input type.
    print(f"Reading {args.input} into memory...")
    with open(args.input, "rb") as f:
        raw = f.read()
    print(f"  Buffer size: {len(raw) / (1024 * 1024):.2f} MiB\n")

    # ------------------------------------------------------------------
    # Group 1: bytestream inputs (full buffer copied into native memory)
    # ------------------------------------------------------------------
    print("=" * 64)
    print("bytestream inputs (whole buffer copied into native memory)")
    print("=" * 64)

    print("\n--- bytes ---")
    exercise_decoder(nvc.SimpleDecoder(raw, gpu_id=args.gpu_id), "bytes")

    print("\n--- bytearray ---")
    exercise_decoder(nvc.SimpleDecoder(bytearray(raw), gpu_id=args.gpu_id), "bytearray")

    print("\n--- memoryview ---")
    exercise_decoder(nvc.SimpleDecoder(memoryview(raw), gpu_id=args.gpu_id), "memoryview")

    # ------------------------------------------------------------------
    # Group 2: BinaryIO stream inputs (bytes pulled on demand, no copy)
    # ------------------------------------------------------------------
    print("\n" + "=" * 64)
    print("BinaryIO stream inputs (bytes pulled on demand, no full copy)")
    print("=" * 64)

    # A file handle is itself a BinaryIO object -- decode straight from it.
    print("\n--- open(path, 'rb') file stream ---")
    with open(args.input, "rb") as file_stream:
        exercise_decoder(nvc.SimpleDecoder(file_stream, gpu_id=args.gpu_id),
                         "file handle (BinaryIO)")

    # io.BytesIO wraps an in-memory buffer as a seekable stream.
    print("\n--- io.BytesIO stream ---")
    exercise_decoder(nvc.SimpleDecoder(io.BytesIO(raw), gpu_id=args.gpu_id),
                     "io.BytesIO (BinaryIO)")

    print("\nDone. SimpleDecoder decoded the same video from "
          "bytes, bytearray, memoryview, and BinaryIO streams.")


if __name__ == "__main__":
    main()
